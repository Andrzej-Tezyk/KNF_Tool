import os
import time
import traceback
from pathlib import Path

import google.generativeai as genai
from dotenv import load_dotenv
from PyPDF2 import PdfReader

load_dotenv()

SCRAPED_FILES_DIR = "scraped_files"
OUTPUT_DIR = Path("output")
SYSTEM_PROMPT = (
    "Do generowania odpowiedzi wykorzystaj tylko"
    + "to co jest zawarte w udostępnionych dokumentach."
)

OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

# Configure Gemini
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")
if not GEMINI_API_KEY:
    raise ValueError("GEMINI_API_KEY not found in environment variables")

genai.configure(api_key=GEMINI_API_KEY)
model = genai.GenerativeModel(
    "gemini-1.5-flash-8b", system_instruction=SYSTEM_PROMPT
)

def extract_text_from_pdf(pdf_path):
    """
    Extract text from a PDF file.
    """
    try:
        with open(pdf_path, "rb") as file:
            pdf = PdfReader(file)
            print(f"Number of pages in {pdf_path}: {len(pdf.pages)}")

            text = ""
            for page in pdf.pages:
                text += page.extract_text() or ""
            
            if not text.strip():
                print(f"Warning: No text extracted from {pdf_path}")
                return ""
                
            return text
    except Exception as e:
        print(f"Error processing {pdf_path}: {str(e)}")
        traceback.print_exc()
        return ""

def process_pdfs_stream(prompt: str, conversation_history: list = None):
    """
    Process PDFs and stream results using Gemini's streaming capability.
    """
    if not prompt:
        yield {"error": "No prompt provided"}
        return

    try:
        pdf_dir = Path(SCRAPED_FILES_DIR)
        if not pdf_dir.exists():
            yield {"error": f"Directory {SCRAPED_FILES_DIR} not found"}
            return

        pdf_files = list(pdf_dir.glob("*.pdf"))
        if not pdf_files:
            yield {"error": f"No PDF files found in {SCRAPED_FILES_DIR}"}
            return

        for pdf_path in pdf_files:
            try:
                text = extract_text_from_pdf(pdf_path)
                if not text:
                    continue

                # Generate streaming response using Gemini
                response = model.generate_content(
                    f"Przeanalizuj poniższy tekst i odpowiedz na pytanie: {prompt}\n\nTekst do analizy:\n{text[:10000]}",
                    stream=True
                )

                yield {
                    "pdf_name": pdf_path.name,
                    "content": ""
                }

                content_buffer = []
                for chunk in response:
                    if chunk.text:
                        content_buffer.append(chunk.text)
                        yield {
                            "pdf_name": pdf_path.name,
                            "content": "".join(content_buffer)
                        }
                
            except Exception as e:
                print(f"Error processing {pdf_path}: {str(e)}")
                continue
                
    except Exception as e:
        yield {"error": str(e)}
