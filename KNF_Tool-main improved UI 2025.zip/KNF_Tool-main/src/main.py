from flask import Flask, request, jsonify, render_template, Response
from flask_cors import CORS
import json
from backend.text_extraction import process_pdfs_stream

app = Flask(__name__)
CORS(app)


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/process", methods=["POST", "GET"])
def process_text():
    try:
        # Handle both POST and GET requests
        prompt = request.form.get("input") or request.args.get("input")
        context = request.form.get("context") or request.args.get("context")
        
        if not prompt:
            return jsonify({"error": "No input provided"}), 400

        # Parse context if provided
        conversation_history = json.loads(context) if context else []

        def generate_results():
            pdfs_to_process = process_pdfs_stream(prompt, conversation_history)
            
            for result in pdfs_to_process:
                yield f"data: {json.dumps(result)}\n\n"

        return Response(
            generate_results(), 
            mimetype='text/event-stream',
            headers={
                'Cache-Control': 'no-cache',
                'Connection': 'keep-alive'
            }
        )

    except Exception as e:
        return jsonify({"error": str(e)}), 500


if __name__ == "__main__":
    app.run(debug=True)
